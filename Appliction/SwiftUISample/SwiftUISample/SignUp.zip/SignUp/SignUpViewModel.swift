//
//  SignUpViewModel.swift
//  SwiftUISample
//
//  Created by Thejas Kasaba on 29/06/26.
//

import Foundation
import Combine

@MainActor
class SignUpViewModel : ObservableObject {
    
    @Published var isLoading : Bool = false
    @Published var errorMessage : String? = nil
    @Published var username : String = ""
    @Published var password : String = ""
    @Published var isSignedUp : Bool = false
    
    private let authService : AuthServiceProtocol
    
    var isValid : Bool { password.count >= 6 }
    
    init(dependency : AuthServiceProtocol) {
        authService = dependency
    }
    
    func signUp() async {
        
        guard isValid else {
            errorMessage = "Invalid credentials"
            return
        }
        
        errorMessage = nil
        isLoading = true
        isSignedUp = false
        
        do {
            
            let token = try await authService.signup(username, password)
            print("Login succeeded : \(token)")
            
            isSignedUp = true
        }
        
        catch {
            errorMessage = error.localizedDescription
        }
        
        isLoading = false
    }
    
    private func fakeAPICall() async throws {
        
        try await Task.sleep(nanoseconds: 2_000_000)
        
        if Bool.random() {
            throw URLError(.badServerResponse)
        }
    }
}
